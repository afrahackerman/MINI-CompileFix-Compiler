#include <stdio.h>
#include <string.h>
#include <ctype.h>

char *keywords[] = {
    "auto","break","case","char","const","continue","default","do","double",
    "else","enum","extern","float","for","goto","if","int","long","register",
    "return","short","signed","sizeof","static","struct","switch","typedef",
    "union","unsigned","void","volatile","while"
};

int isKey( char *word) {
    int n = sizeof(keywords) / sizeof(keywords[0]);
    for (int i = 0; i < n; i++) {
        if (strcmp(word, keywords[i]) == 0)
            return 1;
    }
    return 0;
}

int main() {
    FILE *in;
    char word[100];
    int count = 0;

    in = fopen("q4.txt", "r");
    if (in==NULL) {
        printf("Error opening file!\n");
        return 0;
    }

    while (fscanf(in, "%s", word) == 1) {
        int len = strlen(word);       
        
        // punctuation remove , ( { [ ] } ) ; 
        while (len > 0 && ispunct(word[len - 1])) {
            word[len - 1] = '\0';
            len--;
        }

        if (isKey(word))
            count++;
    }

    fclose(in);
    printf("Number of keywords = %d\n", count);

    return 0;
}