#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int isKey(char *word)
{
    char *keywords[] = {"int","float","if","else","while","for","return","char","double","void","main"};
    int n = sizeof(keywords)/sizeof(keywords[0]);
    for (int i=0; i<n; i++)
    {
        if (strcmp(word, keywords[i]) == 0)
            return 1;
    }
    return 0;
}
int isvalid(char *str)
{
    if(!str||strlen(str)==0)
        return 0;
    if(!(isalpha(str[0])||str[0]=='_'))
        return 0;
      if( isKey(str)){return 0;}
    for(int i=1;str[i]!='\0';i++){
      if(!(isalnum(str[i])||str[i]=='_')) return 0;
    }
return 1;
}

int main()
{
    FILE  *out;
    char str[100];
    int n; scanf("%d",&n);

    out = fopen("q2.txt", "w");
    if (out == NULL)
    {
        printf("Cannot open file.\n");
        return 0;
    }
    for(int i=0;i<n;i++) {
        scanf("%s",&str);
         if(isvalid(str))
        fprintf(out, "valid identifier\n");
    else
        fprintf(out,"invalid\n");
    }
    
   

    fclose(out);
    return 0;
}