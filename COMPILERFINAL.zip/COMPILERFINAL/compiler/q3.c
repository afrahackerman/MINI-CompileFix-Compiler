#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    FILE *in;
    int ch;            
    char num[50];
    int i = 0;
    int dot_seen = 0;    

    in = fopen("q3.txt", "r");
    if (in == NULL) {
        printf("Error opening file!\n");
        return 1;
    }

    while ((ch = fgetc(in)) != EOF) {
        if (isdigit(ch)) {
            if (i < 49) num[i++] = ch;
        } else if (ch == '.' && !dot_seen && i > 0) {
            if (i < 49) num[i++] = ch;
            dot_seen = 1;
        } else {
            if (i > 0) {
                num[i] = '\0';
                printf("%s\n", num);
                i = 0;
                dot_seen = 0;
            }
        }
    }

    if (i > 0) {
        num[i] = '\0';
        printf("%s\n", num);
    }

    fclose(in);
    return 0;
}
