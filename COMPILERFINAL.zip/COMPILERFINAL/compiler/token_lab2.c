
#include <stdio.h>
int isKeyword(char *word)
{
    char *keywords[12] = {"int","float","if","else","while","for","return","char","double","void","main"};
    int n = 11;
    for (int i=0; i<n; i++)
    {
        if (strcmp(word, keywords[i]) == 0) return 1;
    }
    return 0;
}

int main()
{
    FILE *in, *out;
    char ch, buffer[50];
    int i = 0;

    in = fopen("input_lab1.c", "r");
    out = fopen("output_lab2.txt", "w");

    if (in == NULL || out == NULL)
    {
        printf("Cannot open file.\n");
        return 0;
    }

    while ((ch = fgetc(in)) != EOF)
    {
        if (isalnum(ch) || ch == '_')
        {
            buffer[i++] = ch;
        }
        else
        {
            if (i > 0)
            {
                buffer[i] = '\0';
                if (isKeyword(buffer)) //buffer temporary er jonno
                    fprintf(out, "<KEYWORD, %s>\n", buffer);
                else if (isdigit(buffer[0]))
                    fprintf(out, "<NUMBER, %s>\n", buffer);
                else
                    fprintf(out, "<IDENTIFIER, %s>\n", buffer);
                i = 0;
            }

            if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '=')
                fprintf(out, "<OPERATOR, %c>\n", ch);

            else if (ch == ';' || ch == ',' || ch == '(' || ch == ')' || ch == '{' || ch == '}')
                fprintf(out, "<SEPARATOR, %c>\n", ch);
        }
    }

    fclose(in);
    fclose(out);
    return 0;
}
