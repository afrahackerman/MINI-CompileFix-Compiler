#include <stdio.h>
int main() {
    int a, b;
    scanf/* stupid gal */("%d %d", &a, &b);
    int result = a + b;
    printf//
    ("%d", result);
    //
    /*ihcioshvoishv*/
    return 0;
}